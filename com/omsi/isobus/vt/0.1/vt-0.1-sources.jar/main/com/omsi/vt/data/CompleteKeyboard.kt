package com.omsi.vt.data

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class CompleteKeyboard {

    val TAG = "CompleteKeyboard"
    var isVisible by mutableStateOf(false)
    var initialText by mutableStateOf("")
    var maxLength by mutableStateOf(0)
    var isAsciiKeyboard by mutableStateOf(false)
    var enabledCodes by mutableStateOf(BooleanArray(256) { true })



    fun show(initialText :String, isAsciiKeyboard: Boolean, enabledCodes: BooleanArray, maxLength:Int ){
        Log.d(TAG, "Displaying complete keyboard")
        this.initialText = initialText
        this.isAsciiKeyboard = isAsciiKeyboard
        this.enabledCodes = enabledCodes.copyOf()
        this.maxLength = maxLength
        isVisible = true
    }

    fun hide(){
        isVisible = false
    }
}