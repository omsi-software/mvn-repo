package com.omsi.vt.data

import android.content.Context
import android.media.AudioManager

class DeviceAudioManager(context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun setStreamVolume(volumePercent: Float) {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val volume = (maxVolume * volumePercent).toInt()
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            volume,
            0 // Flags: 0 or AudioManager.FLAG_SHOW_UI
        )
    }

    fun getStreamVolume(): Float {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (maxVolume == 0) return 0f
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        return currentVolume.toFloat() / maxVolume
    }
}
