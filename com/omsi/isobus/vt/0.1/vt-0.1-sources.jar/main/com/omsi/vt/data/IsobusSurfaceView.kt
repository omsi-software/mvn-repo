package com.omsi.vt.data

import android.content.Context
import android.graphics.PixelFormat
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView

class IsobusSurfaceView @JvmOverloads constructor(
    context: Context,
    private val vtManager: VtManager,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : SurfaceView(context, attrs, defStyleAttr), SurfaceHolder.Callback {

    init {
        holder.addCallback(this)
        // setZOrderOnTop(true) ensures the SurfaceView is placed on top of its window.
        // To draw Compose UI on top of this, use a Dialog or Popup.
        setZOrderOnTop(true)
        holder.setFormat(PixelFormat.TRANSLUCENT) // Make background transparent
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        vtManager.setNativeWindow(holder.surface)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        vtManager.setNativeWindow(holder.surface)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        vtManager.setNativeWindow(null)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Pass touch events to native renderer
        vtManager.handleInput(event.x, event.y, event.actionMasked, event.eventTime)
        if (event.action == MotionEvent.ACTION_UP) {
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
