package com.omsi.vt.data


//Apollo12 pro landscape dimension in pixels  (screen=1280*800)
val TOP_BAR_HEIGHT = 120
val VT_CANVAS_SIZE = 480 //
val VT_KEY_CONTAINER_WIDTH = 160
val VT_KEY_SIZE = 78 //2 rows of 6 keys, 1px padding around each key
val VT_KEY_PADDING = 1
val VT_WORKING_SET_SIZE = 100
val BOTTOM_BAR_HEIGHT = 200
val BOTTOM_PREVIEW_WIDTH = 200 //(40+160)
