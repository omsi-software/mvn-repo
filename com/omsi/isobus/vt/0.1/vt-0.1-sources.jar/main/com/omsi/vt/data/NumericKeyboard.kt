package com.omsi.vt.data

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale
import kotlin.math.roundToInt

class NumericKeyboard {
    val TAG = "NumericKeyboard"
    var isVisible by mutableStateOf(false)
    var savedRawValue by mutableStateOf(0U) //raw stored value uint32-->long
    var offset by mutableStateOf(0) //signed offset applied to the raw value
    var scale by mutableStateOf(0f) //scale factor to convert raw units to real units
    var numOfDecimals by mutableStateOf(0U) //number of decimals to display
    var minRawValue by mutableStateOf(0U) //minimum allowed raw value
    var maxRawValue by mutableStateOf(0U) //maximum allowed raw value



    fun show(value: UInt, offset:Int, scale:Float, numOfDecimals:UInt, minValue:UInt, maxValue:UInt){
        Log.d(TAG, "Displaying numeric keyboard, value: $value, offset: $offset, scale: $scale, numOfDecimals: $numOfDecimals, minValue: $minValue, maxValue: $maxValue")
        this.isVisible = true
        this.savedRawValue = value
        this.offset = offset
        this.scale = scale
        this.numOfDecimals = numOfDecimals
        this.minRawValue = minValue
        this.maxRawValue = maxValue

    }

    fun hide(){
        isVisible = false
    }

    fun computeConditionedValue(rawValue:UInt):String{
        val value = (rawValue.toLong() + offset) * scale

        // Locale.US is used to ensure the decimal separator is always a dot ('.')
        return String.format(Locale.US, "%.${numOfDecimals}f", value)
    }


    fun getRawValuedFromConditioned(value:String): UInt{
        val conditionedValue = value.toFloatOrNull() ?: 0f
        if(scale == 0f)
            return 0U

        val calculatedRaw = (conditionedValue/scale-offset)

        return calculatedRaw.roundToInt().toUInt()
    }


    fun isValueValid(value:String): Boolean{
        if(value.length==0)
            return false

        val splitted = value.split(".")
        if(splitted.size>2)
            return false
        if(splitted.size==2){
            if(splitted[1].length>numOfDecimals.toInt())
                return false
        }

        val newRawVal = getRawValuedFromConditioned(value)
        if(newRawVal < minRawValue || newRawVal > maxRawValue){
            return false
        }
        return true
    }



}