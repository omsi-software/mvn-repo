package com.omsi.vt.data

import android.content.Context
import android.content.res.AssetManager
import android.view.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class VtManager(val canPort:Int) {

    var started by mutableStateOf(false)
    var numericKeyboard = NumericKeyboard()
    var completeKeyboard = CompleteKeyboard()
    private var deviceAudioManager: DeviceAudioManager? = null


    fun init(context: Context) {
        deviceAudioManager = DeviceAudioManager(context)
        initNative(context.assets)
    }

    fun startVt(){
        if(!started) {
            setVtDimensions(
                VT_CANVAS_SIZE,
                VT_KEY_SIZE,
                VT_KEY_PADDING,
                VT_KEY_CONTAINER_WIDTH,
                VT_WORKING_SET_SIZE
            )
            startVt(canPort)
            started=true
        }
    }

    fun getVtRunning():Boolean{
        started = vtRunning()
        return started
    }


    fun showNumericKeyboard(value:Int, offset:Int, scale:Float, numOfDecimals:Int, minValue:Int, maxValue: Int){
        numericKeyboard.show(value.toUInt(), offset, scale, numOfDecimals.toUInt(), minValue.toUInt(), maxValue.toUInt())
    }

    fun confirmNumericInput(value:Long){
        setValueForInput(false, value, ByteArray(0))
        closeKeyboards()
    }

    fun showCompleteKeyboard(valueBytes: ByteArray, isAsciiKeyboard:Boolean, enabledCodes:BooleanArray, maxLength:Int){
        val value = String(valueBytes, Charsets.ISO_8859_1)
        val cleanValue = value.substringBefore('\u0000')

        //Isobus add a null char at the end, so we need to remove it phisically
        completeKeyboard.show(cleanValue.dropLast(1), isAsciiKeyboard, enabledCodes, maxLength)
    }

    fun confirmTextInput(textValue:String){
        val bytes = textValue.toByteArray(Charsets.ISO_8859_1)
        setValueForInput(true, 0, bytes)
        closeKeyboards()
    }

    fun closeKeyboards(){
        numericKeyboard.hide()
        completeKeyboard.hide()
        closeInputDialog()
    }

    fun setDeviceVolume(volumePercent: Float) {
        deviceAudioManager?.setStreamVolume(volumePercent)
    }

    fun getDeviceVolume(): Float {
        return deviceAudioManager?.getStreamVolume() ?: 0f
    }

    private external fun initNative(assetManager: AssetManager)
    external fun setNativeWindow(surface: Surface?)
    external fun render()
    external fun handleInput(x: Float, y: Float, action: Int, eventTime: Long)
    
    private external fun startVt(port:Int)
    private external fun stopVt()
    private external fun setVtDimensions(mainCanvasSize:Int, softKeyCanvasSize:Int, keyPadding:Int, keyContainerWidth:Int, workingSetCanvasSize:Int)
    private external fun vtRunning(): Boolean
    private external fun setValueForInput(isText:Boolean, numValue:Long, bytes: ByteArray)
    private external fun closeInputDialog()

    external fun playDemoSound(frequency:Int)
    external fun stopPlaying()

    companion object {
        init {
            System.loadLibrary("vtdemo")
        }
    }
}
