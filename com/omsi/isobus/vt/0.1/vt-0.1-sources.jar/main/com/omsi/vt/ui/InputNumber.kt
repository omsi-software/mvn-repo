package com.omsi.vt.ui

import android.view.View
import android.view.Window
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.omsi.vt.data.NumericKeyboard

@Composable
fun InputNumber(
    modifier: Modifier = Modifier,
    data: NumericKeyboard,
    onConfirm: (Long) -> Unit,
    onCancel: () -> Unit,
    surfaceWidth: Dp = Dp.Unspecified,
    surfaceHeight: Dp = Dp.Unspecified
) {
    // Local state to track the typed string before confirming
    var inputString by remember { mutableStateOf(data.computeConditionedValue(data.savedRawValue)) }
    var isError by remember { mutableStateOf(false) }
    val minValue = remember{data.computeConditionedValue(data.minRawValue)}
    val maxValue = remember{data.computeConditionedValue(data.maxRawValue)}

    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        val dialogWindow = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect {
            dialogWindow?.let { window ->
                // Hide system bars (navigation and status) for this dialog's window
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }

        // Full screen container of the dialog
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            // Container limited to surface size
            Box(
                modifier = Modifier
                    .run {
                        if (surfaceWidth != Dp.Unspecified && surfaceHeight != Dp.Unspecified) {
                            size(surfaceWidth, surfaceHeight)
                        } else {
                            fillMaxSize()
                        }
                    }
                    .clickable(enabled = true, onClick = { onCancel() }) // Click outside to close
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                // Keyboard Container
                Surface(
                    modifier = Modifier
                        .width(320.dp)
                        .clickable(enabled = false) {}, // Prevent clicks from passing to background
                    shape = MaterialTheme.shapes.medium,
                    tonalElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Display Area
                        Text(
                            text = inputString,
                            style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .border(2.dp , if(isError) MaterialTheme.colorScheme.error else Color.Transparent)
                                .padding(8.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if(isError){
                            Text(
                                text = "Min: $minValue, Max: $maxValue",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.error,
                                maxLines = 1
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // The Keypad
                            NumericKeypad(
                                onKeyPress = { char ->

                                    if (char === "-") {
                                        if (inputString.contains("-"))
                                            inputString = inputString.replace("-", "")
                                        else
                                            inputString = "-" + inputString
                                    } else {
                                        if (inputString.length < 15)
                                            inputString += char
                                    }

                                    isError = !data.isValueValid(inputString)
                                }
                            )


                            Column(modifier=Modifier.width(100.dp).height(200.dp), verticalArrangement = Arrangement.SpaceBetween){
                                // Full width Delete Button
                                IconButton(
                                    onClick = {
                                        if (inputString.isNotEmpty()) {
                                            inputString = inputString.dropLast(1)
                                            isError = !data.isValueValid(inputString)
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            MaterialTheme.colorScheme.errorContainer,
                                            MaterialTheme.shapes.small
                                        )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }

                                Column(modifier=Modifier){
                                    OutlinedButton(
                                        onClick = onCancel,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Cancel")
                                    }
                                    Button(
                                        onClick = {

                                           val value = data.getRawValuedFromConditioned(inputString)
                                            onConfirm(value.toLong())
                                        },
                                        enabled = !isError,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("OK")
                                    }
                                }
                            }
                        }

                    }


                }
            }
        }
    }
}

@Composable
fun NumericKeypad(
    onKeyPress: (String) -> Unit
) {
    val keys = listOf(
        "1", "2", "3",
        "4", "5", "6",
        "7", "8", "9",
        "-", "0", "."
    )

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.height(200.dp).width(170.dp) // Fixed height for grid
        ) {
            items(keys) { key ->
                Button(
                    onClick = { onKeyPress(key) },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.aspectRatio(1.2f, true),
                    shape = MaterialTheme.shapes.small,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (key == "-" || key == ".")
                            MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                ) {
                    Text(text = key, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }



    }
}

@Preview(device = "spec:width=1280px,height=800px,dpi=240, orientation=landscape", name= "MainScreen", apiLevel = 30,showBackground = true)
@Composable
fun InputNumberPreview() {
    var numericKeyboard = NumericKeyboard()
    numericKeyboard.minRawValue = 10U
    numericKeyboard.maxRawValue = 20U
    numericKeyboard.savedRawValue = 15U
    numericKeyboard.scale = 1f
    numericKeyboard.offset = 0

    Box(modifier=Modifier.width(800.dp).height(400.dp)){
        InputNumber(data = numericKeyboard, onConfirm = {}, onCancel = {})

    }
}
