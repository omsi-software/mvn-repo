package com.omsi.vt.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.SpaceBar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.omsi.vt.data.CompleteKeyboard

enum class KeyboardLayer {
    LOWERCASE, UPPERCASE, SYMBOLS, EXTENDED
}

@Composable
fun InputText(
    modifier: Modifier = Modifier,
    completeKeyboard: CompleteKeyboard,
    onConfirm: (String) -> Unit,
    onCancel: () -> Unit,
    surfaceWidth: Dp = Dp.Unspecified,
    surfaceHeight: Dp = Dp.Unspecified
) {
    var text by remember { mutableStateOf(completeKeyboard.initialText) }

    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        val dialogWindow = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect {
            dialogWindow?.let { window ->
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = modifier
                    .run {
                        if (surfaceWidth != Dp.Unspecified && surfaceHeight != Dp.Unspecified) {
                            size(surfaceWidth, surfaceHeight)
                        } else {
                            fillMaxSize()
                        }
                    }
                    .clickable(enabled = true, onClick = { onCancel() })
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = false, onClick = { }),
                    shape = MaterialTheme.shapes.medium,
                    tonalElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(60.dp),
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Box(
                                    contentAlignment = Alignment.CenterStart,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Text(text = text, style = MaterialTheme.typography.headlineSmall)
                                }
                            }

                            KeyButton(
                                text = "BACKSPACE",
                                isEnabled = true,
                                modifier = Modifier.width(80.dp),
                                onClick = { if (text.isNotEmpty()) text = text.dropLast(1) }
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        AsciiKeyboard(
                            enabledCodes = completeKeyboard.enabledCodes,
                            onKeyPress = {
                                if (text.length < completeKeyboard.maxLength)
                                    text += it
                            },
                            onConfirm = { onConfirm(text) },
                            onCancel = onCancel
                        )
                    }
                }
            }
        }
    }
}

// ... rest of the file (AsciiKeyboard, KeyButton, etc.) remains the same
@Composable
fun AsciiKeyboard(
    enabledCodes: BooleanArray,
    onKeyPress: (String) -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentLayer by remember { mutableStateOf(KeyboardLayer.LOWERCASE) }

    val rows = when (currentLayer) {
        KeyboardLayer.LOWERCASE -> listOf(
            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
            listOf("SHIFT", "z", "x", "c", "v", "b", "n", "m"),
            listOf("?123", "EXT", "SPACE", "CANCEL", "CONFIRM")
        )
        KeyboardLayer.UPPERCASE -> listOf(
            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
            listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"),
            listOf("A", "S", "D", "F", "G", "H", "J", "K", "L"),
            listOf("shift", "Z", "X", "C", "V", "B", "N", "M"),
            listOf("?123", "EXT", "SPACE", "CANCEL", "CONFIRM")
        )
        KeyboardLayer.SYMBOLS -> listOf(
            listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")"),
            listOf("+", "-", "=", "_", "\\", "|", "[", "]", "{", "}"),
            listOf("<", ">", "/", "?", ";", ":", "'", "\"", "`", "~"),
            listOf("ABC", "EXT", "SPACE", "CANCEL", "CONFIRM")
        )
        KeyboardLayer.EXTENDED -> listOf(
            listOf("Ç", "ü", "é", "â", "ä", "à", "å", "ç", "ê", "ë"),
            listOf("è", "ï", "î", "ì", "Ä", "Å", "É", "æ", "Æ", "ô"),
            listOf("ö", "ò", "û", "ù", "ÿ", "Ö", "Ü", "ø", "£", "Ø"),
            listOf("×", "ƒ", "á", "í", "ó", "ú", "ñ", "Ñ", "ª", "º"),
            listOf("ABC", "?123", "SPACE", "CANCEL", "CONFIRM")
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        rows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                row.forEach { key ->
                    val isActionKey = key in listOf("SHIFT", "shift", "BACKSPACE", "?123", "ABC", "CONFIRM", "CANCEL", "EXT", "SPACE")
                    val isEnabled = if (isActionKey) {
                        if (key == "SPACE") enabledCodes[32] else true
                    } else {
                        val charCode = key.firstOrNull()?.code ?: -1
                        charCode in 0..255 && enabledCodes[charCode]
                    }

                    val weight = when (key) {
                        "SPACE" -> 6f
                        "CONFIRM", "CANCEL", "BACKSPACE", "SHIFT", "shift", "?123", "ABC", "EXT" -> 2f
                        else -> 1f
                    }

                    KeyButton(
                        text = key,
                        isEnabled = isEnabled,
                        modifier = Modifier.weight(weight),
                        onClick = {
                            when (key) {
                                "SHIFT" -> currentLayer = KeyboardLayer.UPPERCASE
                                "shift", "ABC" -> currentLayer = KeyboardLayer.LOWERCASE
                                "?123" -> currentLayer = KeyboardLayer.SYMBOLS
                                "EXT" -> currentLayer = KeyboardLayer.EXTENDED
                                "SPACE" -> onKeyPress(" ")
                                "CONFIRM" -> onConfirm()
                                "CANCEL" -> onCancel()
                                else -> onKeyPress(key)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun KeyButton(
    text: String,
    isEnabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerColor = when (text) {
        "CONFIRM" -> MaterialTheme.colorScheme.primary
        "CANCEL" -> MaterialTheme.colorScheme.errorContainer
        "SHIFT", "shift", "BACKSPACE", "?123", "ABC", "EXT" -> MaterialTheme.colorScheme.secondary
        else -> MaterialTheme.colorScheme.surface
    }

    val contentColor = when (text) {
        "CONFIRM" -> MaterialTheme.colorScheme.onPrimary
        "CANCEL" -> MaterialTheme.colorScheme.onErrorContainer
        "SHIFT", "shift", "BACKSPACE", "?123", "ABC", "EXT" -> MaterialTheme.colorScheme.onSecondary
        else -> MaterialTheme.colorScheme.onSurface
    }

    Button(
        onClick = onClick,
        enabled = isEnabled,
        contentPadding = PaddingValues(0.dp),
        shape = MaterialTheme.shapes.extraSmall,
        modifier = modifier.height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
            disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
    ) {
        when (text) {
            "BACKSPACE" -> Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = null, modifier = Modifier.size(18.dp))
            "SHIFT" -> Icon(Icons.Filled.ArrowUpward, contentDescription = null, modifier = Modifier.size(18.dp))
            "shift" -> Icon(Icons.Filled.KeyboardArrowUp, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.Cyan)
            "SPACE" -> Icon(Icons.Filled.SpaceBar, contentDescription = null)
            else -> Text(text = text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Preview(device = "spec:width=1280px,height=800px,dpi=240, orientation=landscape", name= "MainScreen", apiLevel = 30,showBackground = true)
@Composable
fun AsciiKeyboardPreview() {
    val testEnabled = BooleanArray(256) { true }
    for (i in 48..57) testEnabled[i] = false

    val completeKeyboard = CompleteKeyboard()
    completeKeyboard.initialText = "No Numbers Allowed"
    completeKeyboard.enabledCodes = testEnabled

    Box(modifier=Modifier.width(800.dp).height(400.dp)){
        InputText(
            completeKeyboard = completeKeyboard,
            onConfirm = {},
            onCancel = {}
        )
    }
}
