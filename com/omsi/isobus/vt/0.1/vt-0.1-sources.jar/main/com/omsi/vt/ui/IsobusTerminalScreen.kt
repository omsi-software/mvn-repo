package com.omsi.vt.ui

import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.omsi.vt.data.BOTTOM_BAR_HEIGHT
import com.omsi.vt.data.IsobusSurfaceView
import com.omsi.vt.data.VT_CANVAS_SIZE
import com.omsi.vt.data.VT_KEY_CONTAINER_WIDTH
import com.omsi.vt.data.VtManager
import kotlinx.coroutines.delay

@Composable
fun IsobusTerminalScreen(modifier:Modifier=Modifier, canPort:Int = 1) {
    val context = LocalContext.current
    val vtManager = remember {
        VtManager(canPort).apply {
            init(context)
            startVt() //todo manage stop and reconnection?
        }
    }

    // 3. Render Loop
    LaunchedEffect(vtManager) {
        while (true) {
            withFrameNanos {
                vtManager.render()
            }
        }
    }

    val density = LocalDensity.current
    val surfaceHeight = with(density) { (VT_CANVAS_SIZE + BOTTOM_BAR_HEIGHT).toDp() }
    val surfaceWidth = with(density) { (VT_CANVAS_SIZE + VT_KEY_CONTAINER_WIDTH).toDp() }

    Box( modifier = modifier.width(surfaceWidth).height(surfaceHeight)){



            // 1. The Native Layer (The Surface)
            AndroidView(
                factory = { context ->

                    IsobusSurfaceView(context, vtManager)/*.apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            VT_CANVAS_SIZE + BOTTOM_BAR_HEIGHT
                        )
                    }*/
                },
                modifier = Modifier
            )


            if(vtManager.numericKeyboard.isVisible){
                InputNumber(
                    Modifier,
                    vtManager.numericKeyboard,
                    { vtManager.confirmNumericInput(it.toLong()) },
                    { vtManager.closeKeyboards() })
            }

            if(vtManager.completeKeyboard.isVisible){
                InputText(
                    completeKeyboard = vtManager.completeKeyboard,
                    onConfirm = { vtManager.confirmTextInput(it) },
                    onCancel = { vtManager.closeKeyboards() }
                )
            }


        //TopAppBar(modifier=Modifier.align(Alignment.TopStart).height(80.dp).fillMaxWidth(),vtManager = vtManager)

    }

}



@Composable
fun TopAppBar(modifier: Modifier = Modifier, vtManager: VtManager){
    LaunchedEffect(vtManager) {
        vtManager.getVtRunning()
    }
    Box(modifier=modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.secondary), contentAlignment = Alignment.Center){
        Text(modifier=Modifier.align(Alignment.CenterStart),text = "TOP BAR",  fontSize = 36.sp)
        Row(){
            if(!vtManager.started)
                Button(onClick = { vtManager.startVt() }){
                    Text("Start")
                }

            Button(onClick = { vtManager.playDemoSound(1000) }){
                Text("ON")
            }

            Button(onClick = { vtManager.stopPlaying() }){
                Text("OFF")
            }
        }

    }
}